import imgTourYourWay from 'figma:asset/289df7460966406a7c2cb3a55422f0e3dbf872ad.png';
import imgPerformers from 'figma:asset/57a2de3dbb38db4d15b015c0f98d272bf82f919f.png';
import imgEverySceneTitle from 'figma:asset/b013c654bc56ba9e11fa39e36577471953e509d7.png';
import imgFolkShow from 'figma:asset/3bc6e61b4a5cf074b7c1d1a7823d3f58b95e62dc.png';
import imgHardcoreBasement from 'figma:asset/bf2564e8dd07054dfc9581d6cdc8091f2544dce2.png';
import imgJazzBackyard from 'figma:asset/f357d8f54b93a92f6db09fed4ce11e9b02aacbdd.png';
import imgIndiePopRoof from 'figma:asset/c5b8abb3237213419746cb755fb337d9eb249ff9.png';
import imgIntimateCrowd from 'figma:asset/98447d2450b071b127f39ee0314848b139c1ab05.png';
import imgHeroCrowd from 'figma:asset/bc0c6734fcb5aed959ff61810829b5d7a3e805f8.png';
import imgSubtitle from 'figma:asset/8e3f16a219bba6e81bf36568590bbe904944ff8a.png';
import imgHouseVenue from 'figma:asset/d707ffd23cb4017c2d7153b28c38a71b288cb5e2.png';
import imgBringMusic from 'figma:asset/c7d772d44d1d02bc81deb707d8dd417083993fbc.png';

interface HomePageProps {
  onGetStarted: (userType: 'artist' | 'host' | 'fan') => void;
  onSignIn: () => void;
}

export function HomePage({ onGetStarted, onSignIn }: HomePageProps) {
  return (
    <div className="relative w-[1143px] mx-auto bg-[#faf7f2]" style={{ minHeight: '2854px' }}>
      {/* Hero Section */}
      <div className="absolute h-[788px] left-0 overflow-hidden shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-0 w-[1143px]">
        {/* Background Image with Overlay */}
        <div className="absolute h-[785px] left-0 top-0 w-[1143px]">
          <img 
            src={imgIntimateCrowd}
            alt="Intimate concert crowd"
            className="absolute inset-0 max-w-none object-cover pointer-events-none size-full"
          />
          <div className="absolute bg-gradient-to-b from-[rgba(250,247,242,0.95)] h-[785px] left-0 to-[rgba(250,247,242,0.95)] top-0 via-1/2 via-[rgba(250,247,242,0.85)] w-[1143px]" />
        </div>

        {/* Content Container */}
        <div className="absolute h-[669px] left-[59.5px] top-[58px] w-[1024px]">
          {/* Main Heading */}
          <div className="absolute h-[256px] left-[32px] top-[80px] w-[960px]">
            <p className="-translate-x-1/2 absolute font-['Teko:Bold',sans-serif] font-bold leading-[128px] left-[480.3px] text-[#1c1e26] text-[128px] text-center top-[-1px] tracking-[-3.2px] w-[934px] whitespace-pre-wrap">
              Live music, where it actually happens
            </p>
          </div>

          {/* Paragraph */}
          <div className="absolute h-[64px] left-[128px] top-[360px] w-[768px]">
            <p className="-translate-x-1/2 absolute font-['Times:Regular',sans-serif] leading-[32px] left-[384.2px] not-italic text-[#6b6d75] text-[24px] text-center top-0 w-[700px] whitespace-pre-wrap">
              Discover house shows, backyard gigs, and DIY concerts—hosted by real people, not venues.
            </p>
          </div>

          {/* Buttons Container */}
          <div className="absolute content-stretch flex gap-[16px] h-[60px] items-center justify-center left-[32px] pr-[0.008px] top-[472px] w-[960px]">
            <button
              onClick={() => onGetStarted('fan')}
              className="bg-[#c35141] h-[56px] relative rounded-[11.6px] shadow-[0px_20px_25px_0px_rgba(0,0,0,0.1),0px_8px_10px_0px_rgba(0,0,0,0.1)] shrink-0 w-[172.422px] transition-transform duration-200 hover:scale-105 hover:shadow-[0px_24px_30px_0px_rgba(0,0,0,0.15),0px_12px_14px_0px_rgba(0,0,0,0.15)]"
            >
              <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[40px] py-[28px] relative size-full">
                <p className="font-['Teko:Bold',sans-serif] font-bold leading-[28px] relative shrink-0 text-[#faf7f2] text-[20px] text-center">Find a show</p>
              </div>
            </button>
            <button
              onClick={() => onGetStarted('host')}
              className="bg-[#faf7f2] h-[60px] relative rounded-[11.6px] shrink-0 w-[178.945px] transition-transform duration-200 hover:scale-105 hover:shadow-[0px_24px_30px_0px_rgba(0,0,0,0.15),0px_12px_14px_0px_rgba(0,0,0,0.15)]"
            >
              <div aria-hidden="true" className="absolute border-2 border-[#d4cfca] border-solid inset-0 pointer-events-none rounded-[11.6px]" />
              <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[42px] py-[30px] relative size-full">
                <p className="font-['Teko:Bold',sans-serif] font-bold leading-[28px] relative shrink-0 text-[#1c1e26] text-[20px] text-center">Host a show</p>
              </div>
            </button>
          </div>
        </div>

        {/* Houseshow Logo Overlay */}
        <div className="absolute bg-white h-[791px] left-[7px] top-[-3px] w-[1136px] pointer-events-none z-[5]">
          <div className="absolute bg-[#faf7f2] h-[791px] left-[-7px] top-0 w-[1143px]">
            <div className="absolute h-[796px] left-0 overflow-hidden top-0 w-[1143px]">
              <img 
                src={imgHeroCrowd}
                alt=""
                className="absolute inset-0 max-w-none object-cover pointer-events-none size-full"
              />
              {/* D9D9D9 overlay at 65% opacity for brightness/contrast */}
              <div className="absolute bg-[#d9d9d9] opacity-65 h-[793px] left-0 top-0 w-[1143px]" />
              
              <div className="absolute h-[309px] left-[219px] top-[240px] w-[705.531px]">
                <div className="absolute content-stretch flex gap-[16px] h-[48px] items-center justify-center left-[-241px] pr-[0.008px] top-[203px] w-[641.531px]">
                  <button
                    onClick={() => onGetStarted('artist')}
                    className="bg-[#c35141] h-[48px] relative rounded-[11.6px] shrink-0 w-[137.445px] pointer-events-auto transition-transform duration-200 hover:scale-105 hover:shadow-[0px_8px_8px_0px_rgba(0,0,0,0.35)]"
                  >
                    <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[32px] py-[24px] relative size-full">
                      <p className="font-['Teko:Bold',sans-serif] font-bold leading-[28px] relative shrink-0 text-[#faf7f2] text-[18px] text-center">For Artists</p>
                    </div>
                  </button>
                  <button
                    onClick={() => onGetStarted('host')}
                    className="bg-[#c35141] h-[48px] relative rounded-[11.6px] shrink-0 w-[130.242px] pointer-events-auto transition-transform duration-200 hover:scale-105 hover:shadow-[0px_8px_8px_0px_rgba(0,0,0,0.35)]"
                  >
                    <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[32px] py-[24px] relative size-full">
                      <p className="font-['Teko:Bold',sans-serif] font-bold leading-[28px] relative shrink-0 text-[#faf7f2] text-[18px] text-center">For Hosts</p>
                    </div>
                  </button>
                  <button
                    onClick={() => onGetStarted('fan')}
                    className="bg-[#c35141] h-[48px] relative rounded-[11.6px] shrink-0 w-[152px] pointer-events-auto transition-transform duration-200 hover:scale-105 hover:shadow-[0px_8px_8px_0px_rgba(0,0,0,0.35)]"
                  >
                    <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[32px] py-[24px] relative size-full">
                      <p className="font-['Teko:Bold',sans-serif] font-bold leading-[28px] relative shrink-0 text-[#faf7f2] text-[18px] text-center">For Fans</p>
                    </div>
                  </button>
                </div>
                
                <div className="absolute h-[96px] left-[-157px] top-[107px] w-[605px]">
                  <div className="absolute inset-0 overflow-hidden pointer-events-none">
                    <img 
                      src={imgSubtitle}
                      alt="Connecting indie artists, indie fans, indie venues"
                      className="absolute h-[100.44%] left-0 max-w-none top-[-0.22%] w-full brightness-[0.4] contrast-[1.2]"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Sign In Link - positioned at bottom left of hero */}
          <div className="absolute h-[24px] left-[64px] top-[500px] z-10">
            <button 
              onClick={onSignIn}
              className="decoration-solid font-['Teko:SemiBold',sans-serif] font-semibold leading-[24px] text-[#1c1e26] text-[16px] underline hover:text-[#494c57] transition-colors pointer-events-auto"
            >
              Already have an account? Sign in
            </button>
          </div>
          
          <p className="absolute font-['Teko:Bold',sans-serif] font-bold leading-[0] left-[57px] text-[#1c1e26] text-[0px] text-[114px] top-[240px] tracking-[2.28px] w-[1560.976px] whitespace-pre-wrap">
            <span className="leading-[1.2]">House</span>
            <span className="leading-[1.2] text-[#c35141]">show</span>
          </p>
        </div>
      </div>

      {/* Every Scene, Every Sound Section */}
      <div className="absolute bg-white content-stretch flex flex-col gap-[15px] h-[620px] items-start left-0 pt-[106px] px-[32px] top-[751px] w-[1143px]">
        {/* Title Container */}
        <div className="content-stretch flex flex-col gap-[16px] h-[108px] items-start relative shrink-0 w-full">
          <div className="h-[60px] relative shrink-0 w-full">
            <div className="absolute h-[112px] left-[198px] top-[-26px] w-[684px]">
              <img 
                src={imgEverySceneTitle}
                alt="Every Scene, Every Sound"
                className="absolute inset-0 max-w-none object-cover pointer-events-none size-full"
              />
            </div>
          </div>
          <div className="h-[32px] shrink-0 w-full" />
        </div>

        {/* Event Cards Grid */}
        <div className="gap-x-[24px] gap-y-[24px] grid grid-cols-[repeat(4,minmax(0,1fr))] grid-rows-[repeat(1,minmax(0,1fr))] h-[256px] relative shrink-0 w-full">
          {/* Folk Card */}
          <div 
            onClick={() => onGetStarted('fan')}
            className="bg-[#faf7f2] col-1 justify-self-stretch overflow-clip relative rounded-[16px] row-1 self-stretch shadow-[0px_10px_15px_-3px_rgba(0,0,0,0.1),0px_4px_6px_-4px_rgba(0,0,0,0.1)] shrink-0 cursor-pointer transition-transform duration-200 hover:scale-105 hover:shadow-[0px_14px_20px_-3px_rgba(0,0,0,0.15),0px_8px_10px_-4px_rgba(0,0,0,0.15)]">
            <div className="absolute h-[256px] left-0 top-0 w-[251.75px]">
              <img 
                src={imgFolkShow}
                alt="Folk show in a living room"
                className="absolute inset-0 max-w-none object-cover pointer-events-none size-full"
              />
            </div>
            <div className="absolute bg-gradient-to-t from-[rgba(28,30,38,0.6)] h-[256px] left-0 to-[rgba(0,0,0,0)] top-0 w-[251.75px]" />
            <div className="absolute content-stretch flex flex-col h-[48px] items-start left-[16px] top-[192px] w-[219.75px]">
              <div className="h-[28px] relative shrink-0 w-full">
                <p className="absolute font-['Times:Bold',sans-serif] leading-[28px] left-0 not-italic text-[18px] text-white top-[-0.5px]">Folk in a Living Room</p>
              </div>
              <div className="h-[20px] relative shrink-0 w-full">
                <p className="absolute font-['Times:Regular',sans-serif] leading-[20px] left-0 not-italic text-[14px] text-[rgba(255,255,255,0.8)] top-0">Brooklyn • Tonight</p>
              </div>
            </div>
          </div>

          {/* Hardcore Card */}
          <div 
            onClick={() => onGetStarted('fan')}
            className="bg-[#faf7f2] col-2 justify-self-stretch overflow-clip relative rounded-[16px] row-1 self-stretch shadow-[0px_10px_15px_-3px_rgba(0,0,0,0.1),0px_4px_6px_-4px_rgba(0,0,0,0.1)] shrink-0 cursor-pointer transition-transform duration-200 hover:scale-105 hover:shadow-[0px_14px_20px_-3px_rgba(0,0,0,0.15),0px_8px_10px_-4px_rgba(0,0,0,0.15)]">
            <div className="absolute h-[256px] left-0 top-0 w-[251.75px]">
              <img 
                src={imgHardcoreBasement}
                alt="Hardcore basement set"
                className="absolute inset-0 max-w-none object-cover pointer-events-none size-full"
              />
            </div>
            <div className="absolute bg-gradient-to-t from-[rgba(28,30,38,0.6)] h-[256px] left-0 to-[rgba(0,0,0,0)] top-0 w-[251.75px]" />
            <div className="absolute content-stretch flex flex-col h-[48px] items-start left-[16px] top-[192px] w-[219.75px]">
              <div className="h-[28px] relative shrink-0 w-full">
                <p className="absolute font-['Times:Bold',sans-serif] leading-[28px] left-0 not-italic text-[18px] text-white top-[-0.5px]">Hardcore Basement Set</p>
              </div>
              <div className="h-[20px] relative shrink-0 w-full">
                <p className="absolute font-['Times:Regular',sans-serif] leading-[20px] left-0 not-italic text-[14px] text-[rgba(255,255,255,0.8)] top-0">Portland • Friday</p>
              </div>
            </div>
          </div>

          {/* Jazz Card */}
          <div 
            onClick={() => onGetStarted('fan')}
            className="bg-[#faf7f2] col-3 justify-self-stretch overflow-clip relative rounded-[16px] row-1 self-stretch shadow-[0px_10px_15px_-3px_rgba(0,0,0,0.1),0px_4px_6px_-4px_rgba(0,0,0,0.1)] shrink-0 cursor-pointer transition-transform duration-200 hover:scale-105 hover:shadow-[0px_14px_20px_-3px_rgba(0,0,0,0.15),0px_8px_10px_-4px_rgba(0,0,0,0.15)]">
            <div className="absolute h-[256px] left-0 top-0 w-[251.75px]">
              <img 
                src={imgJazzBackyard}
                alt="Jazz in a backyard"
                className="absolute inset-0 max-w-none object-cover pointer-events-none size-full"
              />
            </div>
            <div className="absolute bg-gradient-to-t from-[rgba(28,30,38,0.6)] h-[256px] left-0 to-[rgba(0,0,0,0)] top-0 w-[251.75px]" />
            <div className="absolute content-stretch flex flex-col h-[48px] items-start left-[16px] top-[192px] w-[219.75px]">
              <div className="h-[28px] relative shrink-0 w-full">
                <p className="absolute font-['Times:Bold',sans-serif] leading-[28px] left-0 not-italic text-[18px] text-white top-[-0.5px]">Jazz in a Backyard</p>
              </div>
              <div className="h-[20px] relative shrink-0 w-full">
                <p className="absolute font-['Times:Regular',sans-serif] leading-[20px] left-0 not-italic text-[14px] text-[rgba(255,255,255,0.8)] top-0">Austin • Saturday</p>
              </div>
            </div>
          </div>

          {/* Indie Pop Card */}
          <div 
            onClick={() => onGetStarted('fan')}
            className="bg-[#faf7f2] col-4 justify-self-stretch overflow-clip relative rounded-[16px] row-1 self-stretch shadow-[0px_10px_15px_-3px_rgba(0,0,0,0.1),0px_4px_6px_-4px_rgba(0,0,0,0.1)] shrink-0 cursor-pointer transition-transform duration-200 hover:scale-105 hover:shadow-[0px_14px_20px_-3px_rgba(0,0,0,0.15),0px_8px_10px_-4px_rgba(0,0,0,0.15)]">
            <div className="absolute h-[256px] left-0 top-0 w-[251.75px]">
              <img 
                src={imgIndiePopRoof}
                alt="Indie pop on a roof"
                className="absolute inset-0 max-w-none object-cover pointer-events-none size-full"
              />
            </div>
            <div className="absolute bg-gradient-to-t from-[rgba(28,30,38,0.6)] h-[256px] left-0 to-[rgba(0,0,0,0)] top-0 w-[251.75px]" />
            <div className="absolute content-stretch flex flex-col h-[48px] items-start left-[16px] top-[192px] w-[219.75px]">
              <div className="h-[28px] relative shrink-0 w-full">
                <p className="absolute font-['Times:Bold',sans-serif] leading-[28px] left-0 not-italic text-[18px] text-white top-[-0.5px]">Indie Pop on a Roof</p>
              </div>
              <div className="h-[20px] relative shrink-0 w-full">
                <p className="absolute font-['Times:Regular',sans-serif] leading-[20px] left-0 not-italic text-[14px] text-[rgba(255,255,255,0.8)] top-0">LA • Next Week</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bring the Music Section */}
      <div className="absolute h-[400px] left-[44px] top-[1386px] w-[1079px]">
        <div className="absolute bg-[#e0e4ef] h-[540px] left-[-44px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-[-70px] w-[1143px]" />
        
        <div className="absolute h-[392px] left-0 top-[4px] w-[515.5px]">
          <div className="absolute h-[120px] left-0 top-0 w-[515.5px]" />
          
          {/* Image on the right */}
          <div className="absolute h-[400px] left-[471px] rounded-[24px] top-[-4px] w-[600px]">
            <img 
              src={imgHouseVenue}
              alt="House venue"
              className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[24px] size-full"
            />
          </div>

          {/* List Items */}
          <div className="absolute content-stretch flex flex-col gap-[16px] h-[160px] items-start left-0 top-[144px] w-[515.5px]">
            {/* Item 1 */}
            <div className="h-[28px] relative shrink-0 w-full">
              <div className="absolute bg-[#c35141] content-stretch flex items-center justify-center left-0 rounded-[16777200px] size-[24px] top-[4px]">
                <div className="h-[20px] relative shrink-0 w-[10.703px]">
                  <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                    <p className="absolute font-['Times:Regular','Noto_Sans_Symbols2:Regular',sans-serif] leading-[20px] left-0 not-italic text-[14px] text-white top-0">✓</p>
                  </div>
                </div>
              </div>
              <div className="absolute h-[28px] left-[36px] top-0 w-[400.203px]">
                <p className="absolute font-['Times:Regular',sans-serif] leading-[0] left-0 not-italic text-[#1c1e26] text-[18px] top-[-0.5px]">
                  <span className="font-['Times:Bold',sans-serif] leading-[28px]">Host who you love</span>
                  <span className="leading-[28px]">{` — You choose who plays`}</span>
                </p>
              </div>
            </div>

            {/* Item 2 */}
            <div className="h-[28px] relative shrink-0 w-full">
              <div className="absolute bg-[#c35141] content-stretch flex items-center justify-center left-0 rounded-[16777200px] size-[24px] top-[4px]">
                <div className="h-[20px] relative shrink-0 w-[10.703px]">
                  <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                    <p className="absolute font-['Times:Regular','Noto_Sans_Symbols2:Regular',sans-serif] leading-[20px] left-0 not-italic text-[14px] text-white top-0">✓</p>
                  </div>
                </div>
              </div>
              <div className="absolute h-[28px] left-[36px] top-0 w-[335.172px]">
                <p className="absolute font-['Times:Regular',sans-serif] leading-[0] left-0 not-italic text-[#1c1e26] text-[18px] top-[-0.5px]"><span className="font-['Times:Bold',sans-serif] leading-[28px]"><span className="font-bold">Control who comes</span></span><span className="leading-[28px]"> — Your space, your rules</span></p>
              </div>
            </div>

            {/* Item 3 */}
            <div className="h-[28px] relative shrink-0 w-full">
              <div className="absolute bg-[#c35141] content-stretch flex items-center justify-center left-0 rounded-[16777200px] size-[24px] top-[4px]">
                <div className="h-[20px] relative shrink-0 w-[10.703px]">
                  <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                    <p className="absolute font-['Times:Regular','Noto_Sans_Symbols2:Regular',sans-serif] leading-[20px] left-0 not-italic text-[14px] text-white top-0">✓</p>
                  </div>
                </div>
              </div>
              <div className="absolute h-[28px] left-[36px] top-0 w-[385.141px]">
                <p className="absolute font-['Times:Regular',sans-serif] leading-[0] left-0 not-italic text-[#1c1e26] text-[18px] top-[-0.5px]"><span className="font-['Times:Bold',sans-serif] leading-[28px]"><span className="font-bold">Share details safely</span></span><span className="leading-[28px]"> — Address revealed after RSVP</span></p>
              </div>
            </div>

            {/* Item 4 */}
            <div className="h-[28px] relative shrink-0 w-full">
              <div className="absolute bg-[#c35141] content-stretch flex items-center justify-center left-0 rounded-[16777200px] size-[24px] top-[4px]">
                <div className="h-[20px] relative shrink-0 w-[10.703px]">
                  <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                    <p className="absolute font-['Times:Regular','Noto_Sans_Symbols2:Regular',sans-serif] leading-[20px] left-0 not-italic text-[14px] text-white top-0">✓</p>
                  </div>
                </div>
              </div>
              <div className="absolute h-[28px] left-[36px] top-0 w-[359.43px]">
                <p className="absolute font-['Times:Regular',sans-serif] leading-[0] left-0 not-italic text-[#1c1e26] text-[18px] top-[-0.5px]"><span className="font-['Times:Bold',sans-serif] leading-[28px]"><span className="font-bold">Collect ticket money</span></span><span className="leading-[28px]"> — Simple, transparent split</span></p>
              </div>
            </div>
          </div>

          {/* Button */}
          <button
            onClick={() => onGetStarted('host')}
            className="absolute bg-[#c35141] h-[56px] left-0 rounded-[11.6px] shadow-[0px_20px_25px_0px_rgba(0,0,0,0.1),0px_8px_10px_0px_rgba(0,0,0,0.1)] top-[336px] w-[236.5px] transition-transform duration-200 hover:scale-105 hover:shadow-[0px_24px_30px_0px_rgba(0,0,0,0.15),0px_12px_14px_0px_rgba(0,0,0,0.15)]"
          >
            <p className="-translate-x-1/2 absolute font-['Teko:Bold',sans-serif] font-bold leading-[28px] left-[118.5px] text-[#faf7f2] text-[20px] text-center top-[13.5px] whitespace-nowrap">Host your first show</p>
          </button>
        </div>

        {/* Title Image */}
        <div className="absolute content-stretch flex flex-col items-start left-[-22px] p-[10px] top-[-11px] w-[447px]">
          <div className="aspect-[2693/967] relative shrink-0 w-full">
            <img 
              src={imgBringMusic}
              alt="Bring the music to you"
              className="absolute inset-0 max-w-none object-cover pointer-events-none size-full"
            />
          </div>
        </div>
      </div>

      {/* Tour Your Way Section */}
      <div className="absolute bg-white h-[506px] left-0 shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-[1856px] w-[1143px]">
        <div className="absolute h-[407px] left-[634px] top-[123px] w-[484px]">
          {/* List Items */}
          <div className="absolute content-stretch flex flex-col gap-[16px] items-start left-0 top-[144px] w-[484px]">
            {/* Item 1 */}
            <div className="h-[28px] relative shrink-0 w-full">
              <div className="absolute bg-[#c35141] content-stretch flex items-center justify-center left-0 rounded-[16777200px] size-[24px] top-[4px]">
                <div className="h-[20px] relative shrink-0 w-[10.703px]">
                  <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                    <p className="absolute font-['Times:Regular','Noto_Sans_Symbols2:Regular',sans-serif] leading-[20px] left-0 not-italic text-[14px] text-white top-0">✓</p>
                  </div>
                </div>
              </div>
              <div className="absolute h-[28px] left-[36px] top-0 w-[406.625px]">
                <p className="absolute font-['Times:Regular',sans-serif] leading-[0] left-0 not-italic text-[#1c1e26] text-[18px] top-[-0.5px]"><span className="font-['Times:Bold',sans-serif] leading-[28px]"><span className="font-bold">Direct support</span></span><span className="leading-[28px]"><span className="font-bold"> </span>— Ticket sales go straight to you</span></p>
              </div>
            </div>

            {/* Item 2 */}
            <div className="h-[28px] relative shrink-0 w-full">
              <div className="absolute bg-[#c35141] content-stretch flex items-center justify-center left-0 rounded-[16777200px] size-[24px] top-[4px]">
                <div className="h-[20px] relative shrink-0 w-[10.703px]">
                  <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                    <p className="absolute font-['Times:Regular','Noto_Sans_Symbols2:Regular',sans-serif] leading-[20px] left-0 not-italic text-[14px] text-white top-0">✓</p>
                  </div>
                </div>
              </div>
              <div className="absolute h-[28px] left-[36px] top-0 w-[394.18px]">
                <p className="absolute font-['Times:Regular',sans-serif] leading-[0] left-0 not-italic text-[#1c1e26] text-[18px] top-[-0.5px]"><span className="font-['Times:Bold',sans-serif] leading-[28px]"><span className="font-bold">No complicated venues</span></span><span className="leading-[28px]"> — Just you, the host, and us</span></p>
              </div>
            </div>

            {/* Button */}
            <button
              onClick={() => onGetStarted('artist')}
              className="bg-[#c35141] h-[56px] relative rounded-[11.6px] shadow-[0px_20px_25px_0px_rgba(0,0,0,0.1),0px_8px_10px_0px_rgba(0,0,0,0.1)] shrink-0 w-[234.602px] transition-transform duration-200 hover:scale-105 hover:shadow-[0px_24px_30px_0px_rgba(0,0,0,0.15),0px_12px_14px_0px_rgba(0,0,0,0.15)]"
            >
              <p className="-translate-x-1/2 absolute font-['Teko:Bold',sans-serif] font-bold leading-[28px] left-[117.5px] text-[#faf7f2] text-[20px] text-center top-[13.5px] whitespace-nowrap">Start playing shows</p>
            </button>

            <div className="h-[28px] shrink-0 w-full" />
          </div>

          {/* Real connections item */}
          <div className="absolute bg-[#c35141] content-stretch flex items-center justify-center left-0 rounded-[16777200px] size-[24px] top-[111px]">
            <div className="h-[20px] relative shrink-0 w-[10.703px]">
              <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                <p className="absolute font-['Times:Regular','Noto_Sans_Symbols2:Regular',sans-serif] leading-[20px] left-0 not-italic text-[14px] text-white top-0">✓</p>
              </div>
            </div>
          </div>
          <div className="absolute h-[28px] left-[36px] top-[107px] w-[372.438px]">
            <p className="absolute font-['Times:Regular',sans-serif] leading-[0] left-0 not-italic text-[#1c1e26] text-[18px] top-0"><span className="font-['Times:Bold',sans-serif] leading-[28px]"><span className="font-bold">Real connections</span></span><span className="leading-[28px]"> — Be </span><span className="font-['Times:Italic',sans-serif] italic leading-[28px]">with </span><span className="leading-[28px]">your audience</span></p>
            <div className="absolute h-[364px] left-[-631px] rounded-[33px] top-[-158px] w-[546px]">
              <img 
                src={imgPerformers}
                alt="Performers"
                className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[33px] size-full"
              />
            </div>
          </div>

          {/* Title Image */}
          <div className="absolute h-[162px] left-[-15px] top-[-49px] w-[355px]">
            <img 
              src={imgTourYourWay}
              alt="Tour your way"
              className="absolute inset-0 max-w-none object-cover pointer-events-none size-full"
            />
          </div>
        </div>
      </div>

      {/* Find a Show Section */}
      <div className="absolute bg-[#c35141] content-stretch flex flex-col gap-[32px] h-[492px] items-start left-0 pt-[128px] px-[123.5px] top-[2362px] w-[1143px]">
        <div className="h-[144px] relative shrink-0 w-full">
          <p className="-translate-x-1/2 absolute font-['Teko:Bold',sans-serif] font-bold leading-[72px] left-[448.27px] text-[#faf7f2] text-[72px] text-center top-[0.5px] tracking-[-1.8px] w-[750px] whitespace-pre-wrap">
            {`Your next favorite concert is in someone's living room.`}
          </p>
        </div>

        <div className="h-[60px] relative shrink-0 w-full">
          <div className="flex flex-row items-center justify-center size-full">
            <div className="content-stretch flex items-center justify-center pr-[0.008px] relative size-full">
              <button
                onClick={() => onGetStarted('fan')}
                className="bg-[#f5e6e3] h-[56px] relative rounded-[11.6px] shadow-[0px_20px_25px_0px_rgba(0,0,0,0.1),0px_8px_10px_0px_rgba(0,0,0,0.1)] shrink-0 w-[172.422px] transition-transform duration-200 hover:scale-105 hover:shadow-[0px_24px_30px_0px_rgba(0,0,0,0.15),0px_12px_14px_0px_rgba(0,0,0,0.15)]"
              >
                <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[40px] py-[28px] relative size-full">
                  <p className="font-['Teko:Bold',sans-serif] font-bold leading-[28px] relative shrink-0 text-[#1c1e26] text-[20px] text-center">Find a show</p>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}