
  # House Listing Feature

  This is a code bundle for House Listing Feature. The original project is available at https://www.figma.com/design/6ZOark0etBufzq3p4yanVK/House-Listing-Feature.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  